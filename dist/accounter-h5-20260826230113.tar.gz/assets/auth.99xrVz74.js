import{y as r,z as s}from"./index-FGVU-6y2.js";import{T as e}from"./request.DJvip3vF.js";function o(){return!!s(e)||(r({url:"/pages/login/index"}),!1)}export{o as c};
