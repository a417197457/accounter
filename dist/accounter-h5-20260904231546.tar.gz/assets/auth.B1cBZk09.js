import{y as r,z as s}from"./index-DJ1b2MQX.js";import{T as e}from"./request.DUutPid4.js";function o(){return!!s(e)||(r({url:"/pages/login/index"}),!1)}export{o as c};
