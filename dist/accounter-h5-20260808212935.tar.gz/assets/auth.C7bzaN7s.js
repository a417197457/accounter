import{u as r,z as s}from"./index-CaMp_cgu.js";import{T as e}from"./request.DhkYkrhc.js";function o(){return!!s(e)||(r({url:"/pages/login/index"}),!1)}export{o as c};
