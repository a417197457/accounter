import{u as r,z as s}from"./index-Cq3D9Ke2.js";import{T as e}from"./request.DOm9gaW3.js";function o(){return!!s(e)||(r({url:"/pages/login/index"}),!1)}export{o as c};
