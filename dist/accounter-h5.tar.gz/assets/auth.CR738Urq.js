import{q as r,y as s}from"./index-CmkIPE-U.js";import{T as e}from"./request.CSWpgMxi.js";function o(){return!!s(e)||(r({url:"/pages/login/index"}),!1)}export{o as c};
