import{u as r,z as s}from"./index-BC3xoXmZ.js";import{T as e}from"./request.BVY400k-.js";function o(){return!!s(e)||(r({url:"/pages/login/index"}),!1)}export{o as c};
